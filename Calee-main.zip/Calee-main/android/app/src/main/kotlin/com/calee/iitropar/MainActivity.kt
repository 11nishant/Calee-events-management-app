package com.example.iitropar

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
