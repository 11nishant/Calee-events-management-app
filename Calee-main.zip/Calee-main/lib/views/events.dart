// ignore_for_file: non_constant_identifier_names

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:iitropar/frequently_used.dart';
import 'package:iitropar/utilities/colors.dart';
import 'package:intl/intl.dart';

//to do build a function to access all the events
class Events extends StatefulWidget {
  const Events({super.key});

  @override
  State<Events> createState() => _EventsState();
}

class EventCard extends StatefulWidget {
final String eventId;
final String eventTitle;
final String eventType;
final String eventDesc;
final String eventVenue;
final String date;
final String startTime;
final String endTime;
final String? img_url;
final bool isStarred;

const EventCard
({
  super.key,
  required this.eventId,
required this.eventTitle,
required this.eventType,
required this.eventDesc,
required this.eventVenue,
required this.date,
required this.startTime,
required this.endTime,
required this.img_url,
required this.isStarred,
});

@override
_EventCardState createState() => _EventCardState();

}
class _EventCardState extends State<EventCard> {
  late bool _isStarred;
  late String eventTitle;
  late String eventType;
  late String eventDesc;
  late String eventVenue;
  late String date;
  late String startTime;
  late String endTime;
  late String? img_url;
  late String eventId;

  @override
  void initState() {
    super.initState();
    _isStarred = widget.isStarred;
    eventTitle = widget.eventTitle;
    eventType = widget.eventType;
    eventDesc = widget.eventDesc;
    eventVenue = widget.eventVenue;
    date = widget.date;
    startTime = widget.startTime;
    endTime = widget.endTime;
    img_url = widget.img_url;
    eventId = widget.eventId;
  }

  Widget build(BuildContext context) {
    double swidth = MediaQuery
        .of(context)
        .size
        .width;
    swidth /= 410;

    return Container(
      padding: EdgeInsets.all(10 * swidth),
      margin: EdgeInsets.all(15 * swidth),
      decoration: BoxDecoration(
          color: Colors.blueGrey[100], borderRadius: BorderRadius.circular(10)),
      child: InkWell(
        onTap: () {
          showDialog(
              context: context,
              builder: (BuildContext context) {
                return SimpleDialog(
                  title: Column(
                    children: [
                      img_url == null
                          ? const SizedBox(height: 5)
                          : Image.network(img_url!,
                          errorBuilder: (context, error, stackTrace) =>
                          const SizedBox(height: 20)),
                      Text(
                        eventTitle,
                        style: const TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 26),
                      ),
                      Text(
                        "Event Type : $eventType",
                        style: const TextStyle(fontSize: 16),
                      ),
                    ],
                  ),
                  contentPadding: const EdgeInsets.all(20),
                  children: [
                    const Text("Description",
                        style:
                        TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
                    const SizedBox(
                      height: 5,
                    ),
                    Text(eventDesc),
                    const SizedBox(
                      height: 15,
                    ),
                    const Text("Venue",
                        style:
                        TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
                    const SizedBox(
                      height: 5,
                    ),
                    Text(eventVenue),
                  ],
                );
              });
        },
        child: Row(children: [
          Container(
            padding: EdgeInsets.all(5 * swidth),
            decoration: BoxDecoration(
              color: Colors.amberAccent[100],
              borderRadius: BorderRadius.circular(10),
            ),
            height: 70 * swidth,
            width: 40 * swidth,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                SizedBox(
                  height: 15,
                  child: FittedBox(
                    child: Text(
                      date,
                    ),
                  ),
                ),
                const SizedBox(
                  height: 5,
                ),
                SizedBox(
                  height: 26,
                  child: FittedBox(
                    child: Text(
                      startTime,
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                  ),
                )
              ],
            ),
          ),
          SizedBox(
            width: 10 * swidth,
          ),
          SizedBox(
            height: 70 * swidth,
            width: 200 * swidth,
// color: Colors.amber,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  height: 26,
                  child: FittedBox(
                    child: Text(
                      eventTitle,
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
                const SizedBox(
                  height: 3.69,
                ),
                Flexible(
                    child: Text(
                      eventDesc,
                      overflow: TextOverflow.ellipsis,
                      maxLines: 2,
                    )),
              ],
            ),
          ),
          SizedBox(
            width: 10 * swidth,
          ),
          Container(
            padding: EdgeInsets.all(5 * swidth),
            decoration: BoxDecoration(
              color: Colors.greenAccent[100],
              borderRadius: BorderRadius.circular(10),
            ),
            height: 70 * swidth,
            width: 70 * swidth,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                SizedBox(height: 15, child: FittedBox(child: Text(eventType))),
                const SizedBox(
                  height: 5,
                ),
                SizedBox(
                  height: 26,
                  child: FittedBox(
                      child: Text(
                        endTime,
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      )),
                )
              ],
            ),
          ),
          SizedBox(
            width: 5 * swidth,
          ),
          GestureDetector(
            onTap: () {
              setState(() {
                _isStarred = !_isStarred;
              });
              handleStarred(_isStarred,eventId);
            },
            child: Icon(
              _isStarred ? Icons.star : Icons.star_border,
              color: _isStarred ? Colors.purple : null,
            ),
          ),
        ]),
      ),
    );
  }

  Future<void> handleStarred(bool isStarred,String eventId) async {

    DocumentReference starredCollection = FirebaseFirestore.instance
        .collection("Event.nonrecurring")
        .doc(eventId);

    try {
      if (isStarred) {
        await starredCollection.update({
          "starredBy": FieldValue.arrayUnion([FirebaseAuth.instance.currentUser!.email!]),
        });
      } else if (!isStarred){
        await starredCollection.update({
          "starredBy": FieldValue.arrayRemove([FirebaseAuth.instance.currentUser!.email!]),
        });
      }
    } catch (error) {
      print('Error: $error');
    }
  }
}

  Card eventWidget(
      String eventTitle,
      String eventType,
      String eventDesc,
      String eventVenue,
      String date,
      String startTime,
      String endTime,
      String? img_url) {
    return Card(
        elevation: 4.0,
        child: Column(
          children: [
            ListTile(
              title: Text(eventTitle),
              subtitle: Text(eventType),
              trailing: const Icon(Icons.favorite_outline),
            ),
            Center(
                child: img_url == null
                    ? const SizedBox(height: 20)
                    : Image.network(img_url,
                    errorBuilder: (context, error, stackTrace) =>
                    const SizedBox(height: 20))),
            Container(
              padding: const EdgeInsets.all(16.0),
              alignment: Alignment.centerLeft,
              child: Text(
                'Venue : $eventVenue',
                overflow: TextOverflow.ellipsis,
              ),
            ),
            Container(
              padding: const EdgeInsets.all(16.0),
              alignment: Alignment.centerLeft,
              child: Text(
                'Desc : $eventDesc',
                overflow: TextOverflow.ellipsis,
              ),
            ),
            Container(
              padding: const EdgeInsets.all(16.0),
              alignment: Alignment.centerLeft,
              child: Text(
                'Date : $date',
                overflow: TextOverflow.ellipsis,
              ),
            ),
            Container(
              padding: const EdgeInsets.all(16.0),
              alignment: Alignment.centerLeft,
              child: Text(
                'Timing : $startTime - $endTime',
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ],
        ));
  }


class _EventsState extends State<Events> {
  DateTime? _selectedDate;
  bool _showStarredEvents = false;
  _EventsState() {
    _selectedDate = DateTime.now();
    _showStarredEvents = false;
  }
  Future<bool> checkIfStarred(String eventId) async {
    DocumentSnapshot docSnapshot = await FirebaseFirestore.instance
      .collection("Event.nonrecurring")
      .doc(eventId)
      .get();
    if (docSnapshot.exists) {
      var data = docSnapshot.data() as Map<String, dynamic>?;
      if (data != null && data.containsKey('starredBy')) {
        var starredBy = docSnapshot.get("starredBy");
        if (starredBy != null) {
          var currentUserEmail = FirebaseAuth.instance.currentUser!.email;
          return starredBy.contains(currentUserEmail);
        }
      }

    }
    return false;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          toolbarHeight: 50,
          title: buildTitleBar("EVENTS", context),
          elevation: 0,
          backgroundColor: Colors.blue,
        ),
        // drawer: const NavDrawer(),
        body: Column(
          children: [
            ListTile(
              title: Text(
                "Show Starred Events",
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 14,
                  color: Colors.black87,
                ),
              ),
              subtitle: Text(
                "Toggle to show only starred events",
                style: TextStyle(
                  fontSize: 12,
                  color: Colors.grey[600],
                ),
              ),
              trailing: Switch(
                value: _showStarredEvents,
                onChanged: (newValue) {
                  setState(() {
                    _showStarredEvents = newValue;
                  });
                },
                activeColor: Colors.blue, // Color when switch is on
                inactiveThumbColor: Colors.grey[300], // Color of switch when off
                inactiveTrackColor: Colors.grey[400],
              ),

            ),
            Expanded(
              child: StreamBuilder(
                  stream: FirebaseFirestore.instance
                      .collection("Event.nonrecurring")
                      .orderBy("eventDate")
                      .snapshots()
                  ,
                  builder: (context, snapshot) {
                    if (snapshot.hasData) {
                      List<QueryDocumentSnapshot> filteredDocs =[];
                      if(_showStarredEvents==true){
                        filteredDocs = snapshot.data!.docs.where((doc) {
                          var data = doc.data() as Map<String, dynamic>?;
                          if (data != null && data.containsKey('starredBy')) {
                            var starredBy = doc.get("starredBy");
                            if (starredBy != null) {
                              var currentUserEmail = FirebaseAuth.instance.currentUser!.email;
                              String doc_eventDate0 = doc.get("eventDate");
                              List<String> date_split = doc_eventDate0.split('/');
                              DateTime doc_eventDate = DateTime(
                                int.parse(date_split[2]),
                                int.parse(date_split[1]),
                                int.parse(date_split[0]),
                              );
                              DateTime endDate = _selectedDate!.add(const Duration(days: 5));
                              return starredBy.contains(currentUserEmail) &&((doc_eventDate.isAfter(_selectedDate!) || doc_eventDate.isAtSameMomentAs(_selectedDate!)) && doc_eventDate.isBefore(endDate));
                            }
                            else {return false;}
                          }
                          else {return false;}
                        }).toList();
                      }
                      else{
                        filteredDocs = snapshot.data!.docs.where((doc) {
                          String doc_eventDate0 = doc["eventDate"];
                          List<String> date_split = doc_eventDate0.split('/');
                          DateTime doc_eventDate = DateTime(
                            int.parse(date_split[2]),
                            int.parse(date_split[1]),
                            int.parse(date_split[0]),
                          );
                          DateTime endDate = _selectedDate!.add(const Duration(days: 5));
                          return doc_eventDate.isBefore(_selectedDate!.add(const Duration(days: 5))) &&(doc_eventDate.isAfter(_selectedDate!) || doc_eventDate.isAtSameMomentAs(_selectedDate!));
                        }).toList();
                      }

                      filteredDocs.sort((doc1, doc2) {
                        String doc_eventDate1 = doc1["eventDate"];
                        String doc_eventDate2 = doc2["eventDate"];

                        List<String> date_split1 = doc_eventDate1.split('/');
                        List<String> date_split2 = doc_eventDate2.split('/');

                        DateTime date1 = DateTime(
                          int.parse(date_split1[2]),
                          int.parse(date_split1[1]),
                          int.parse(date_split1[0]),
                        );
                        DateTime date2 = DateTime(
                          int.parse(date_split2[2]),
                          int.parse(date_split2[1]),
                          int.parse(date_split2[0]),
                        );

                        int dateComparison = date1.compareTo(date2);

                        if (dateComparison == 0) {
                          // If dates are the same, compare by startTime
                          String startTime1 = doc1["startTime"];
                          String startTime2 = doc2["startTime"];

                          return startTime1.compareTo(startTime2);
                        } else {
                          // Otherwise, compare by eventDate
                          return dateComparison;
                        }
                      });

                      return ListView.builder(
                          shrinkWrap: true,
                          itemCount: filteredDocs.length,
                          itemBuilder: (context, index) {
                            DocumentSnapshot doc = filteredDocs[index];

                            return FutureBuilder<bool>(
                              future: checkIfStarred(doc.id),
                              builder: (context, snapshot) {
                                if (snapshot.connectionState == ConnectionState.waiting) {
                                  return CircularProgressIndicator();
                                } else if (snapshot.hasError) {
                                  return Text('Error: ${snapshot.error}');
                                } else {
                                  bool isStarred = snapshot.data!;
                                  return EventCard(
                                      eventTitle:doc["eventTitle"],
                                      eventType: doc["eventType"],
                                      eventDesc:doc["eventDesc"],
                                      eventVenue:doc["eventVenue"],
                                      date:doc["eventDate"],
                                      startTime:doc["startTime"],
                                      endTime:doc["endTime"],
                                      img_url:doc["imgURL"],
                                      isStarred:isStarred,
                                      eventId: doc.id,
                                  );
                                }
                              },
                            );
                          });
                    } else {
                      return Container();
                    }
                  }),
            ),
          ],
        ),
        backgroundColor: Colors.blueGrey[50],
        bottomNavigationBar: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              style: ButtonStyle(
                backgroundColor: MaterialStateColor.resolveWith(
                        (states) => Colors.blue),
              ),
              onPressed: () async {
                showDatePicker(
                    context: context,
                    initialDate: DateTime.now(),
                    firstDate: DateTime(1900),
                    lastDate: DateTime(2100))
                    .then((date) {
                  if (date == null) return;
                  setState(() {
                    _selectedDate = date;
                  });
                });
              },
              child: const Text("Select Date", style: TextStyle(color: Colors.black),),
            ),
            IconButton(
              onPressed: () {
                setState(() {
                  if (_selectedDate != null) {
                    _selectedDate =
                        _selectedDate!.subtract(const Duration(days: 1));
                  }
                });
              },
              icon: const Icon(Icons.arrow_left),
            ),
            Text(DateFormat('dd-MM-yyyy').format(_selectedDate!)),
            IconButton(
              onPressed: () {
                setState(() {
                  if (_selectedDate != null) {
                    _selectedDate = _selectedDate!.add(const Duration(days: 1));
                  }
                });
              },
              icon: const Icon(Icons.arrow_right),
            ),
          ],
        )); // Generated code for this Row Widget...
  }
  Widget themeButtonWidget() {
    return IconButton(
      onPressed: () {},
      icon: const Icon(
        Icons.sync_rounded,
      ),
      color: Color(primaryLight),
      iconSize: 28,
    );
  }

  TextStyle appbarTitleStyle() {
    return TextStyle(
        color: Color(primaryLight),
        // fontSize: 24,
        fontWeight: FontWeight.bold,
        letterSpacing: 1.5);
  }

  Row buildTitleBar(String text, BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        IconButton(
          onPressed: () {},
          icon: const Icon(Icons.sync_rounded),
          color: Colors.white, // Change to your preferred color
          iconSize: 28,
        ),
        Text(
          text,
          style: const TextStyle(
            color: Colors.white, // Change to your preferred color
            fontWeight: FontWeight.bold,
            letterSpacing: 1.5,
          ),
        ),
        signoutButtonWidget(context),
      ],
    );
  }
}
