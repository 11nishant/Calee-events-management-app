int primaryLight = 0xff333333;
int secondaryLight = 0xfffafafa;
int holidayColor = 0xffFF8888;
